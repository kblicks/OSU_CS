#include <iostream>
#include "p_classes.h"

int main(int argc, char *argv[])
{
    Card c1;
    cout << "call deck" << endl;
    Deck d;
    c1.map_suit();

    c1.print_card();
    cout << "Concludes main" << endl;
}